#pragma once

/*
* 
* Disabling This Enumerated Data Type Class as I am unable to get the value to pass through my function currently unless I include the class identifier. 
* 
* Using the enumerated data type only, below, I am able to pass only the value through the functions and get successfully assignment. 
* 
// ENUMERATED DATA TYPE CLASS

enum class DegreeProgram {
	NETWORK = 0, 
	SOFTWARE, 
	SECURITY

};
*/

// ENUMERATED DATA TYPE 

enum DegreeProgram {
    NETWORK = 0,
    SOFTWARE,
    SECURITY

};

